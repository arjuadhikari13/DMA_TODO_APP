### Todo Application

Final project for DMA Year 4 sem 2. It is a native java application with clean UI.
